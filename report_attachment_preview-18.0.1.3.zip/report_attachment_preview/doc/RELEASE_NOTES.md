## Module <report_attachment_preview>

#### 25.09.2024
#### Version 18.0.1.0.0
#### ADD
- Initial Commit for Reports and Attachments Preview in Browser

#### 29.10.2024
#### Version 18.0.1.0.0
#### Bug fixes
 - Resolved the style issue of the related products
