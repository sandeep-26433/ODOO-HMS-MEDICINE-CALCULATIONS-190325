## Module <odoo_dynamic_dashboard>

#### 15.10.2024
#### Version 18.0.1.0.0
##### ADD
- Initial commit for Odoo Dynamic Dashboard

#### 03.01.2025
#### Version 18.0.1.0.1
##### FIX
- Updated issue related to the cdn used and updated the style issue

#### 12.03.2025
#### Version 18.0.1.0.2
##### FIX
- Updated issue related to the filtering