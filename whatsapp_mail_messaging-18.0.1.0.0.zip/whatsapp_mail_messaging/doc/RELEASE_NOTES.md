## Module <whatsapp_mail_messaging>

#### 30.10.2024
#### Version 18.0.1.0.0
##### ADD
- Initial commit for Odoo Whatsapp Connector
